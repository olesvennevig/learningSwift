// Playground - noun: a place where people can play

import Cocoa

/*
let dogName = "Charles"

var dogAge = 14,💩👹 = "Nasty Stuff",dogWeight = 134

💩👹

var dogName: Double;

dogName = 342

var dogName = "Raplph";

var dogName:Int;
dogName = 42


typealias Strang = String

var dogName: Strang

dogName = "Ralph"

typealias 😠 = Double


var isAlive = true
var isAlive2 = false



var myDog = (42, "ralph", true)

myDog.1

var myCat = (age: 2,name: "Tigergutt",isAFemale: true)

myCat.1


var myCat = (age: 2,name: "Tigergutt",isAFemale: true)
var (_,name,_) = myCat

name

// var (age,name,isAFemale) = myCat

age

name

isAFemale


var dogWeight = 5.34 + 455


var dogAge = "123".toInt()

*/






